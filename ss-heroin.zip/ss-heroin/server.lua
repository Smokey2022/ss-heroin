local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('ss-heroincar:start')
AddEventHandler('ss-heroincar:start', function()
	local _source = source
	local Player = QBCore.Functions.GetPlayer(source)
	local ItemPainkillers = Player.Functions.GetItemByName("painkillers")
    local ItemOpium = Player.Functions.GetItemByName("opium")
	local ItemMethlab = Player.Functions.GetItemByName("methlab")
	if ItemPainkillers ~= nil and ItemOpium ~= nil and ItemMethlab ~= nil then
		if ItemPainkillers.amount >= 5 and ItemOpium.amount >= 2 and ItemMethlab.amount >= 1 then	
			TriggerClientEvent("ss-heroincar:startprod", _source)
			Player.Functions.RemoveItem("painkillers", 5, false)
			Player.Functions.RemoveItem("opium", 2, false)
		else
		TriggerClientEvent('QBCore:Notify', source, "You don't have enough ingredients to cook!", 'error')
		end	
	else
	TriggerClientEvent('QBCore:Notify', source, "You're missing essential ingredients!", 'error')
	end	
end)

RegisterServerEvent('ss-heroincar:stopf')
AddEventHandler('ss-heroincar:stopf', function(id)
local _source = source
	local xPlayers = QBCore.Functions.GetPlayers()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	for i=1, #xPlayers, 1 do
		TriggerClientEvent('ss-heroincar:stopfreeze', xPlayers[i], id)
	end	
end)

RegisterServerEvent('ss-heroincar:make')
AddEventHandler('ss-heroincar:make', function(posx,posy,posz)
	local _source = source
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	if xPlayer.Functions.GetItemByName('methlab') ~= nil then
		if xPlayer.Functions.GetItemByName('methlab').amount >= 1 then	
			local xPlayers = QBCore.Functions.GetPlayers()
			for i=1, #xPlayers, 1 do
				TriggerClientEvent('ss-heroincar:smoke',xPlayers[i],posx,posy,posz, 'a') 
			end		
		else
			TriggerClientEvent('ss-heroincar:stop', _source)
		end
	else
	TriggerClientEvent('QBCore:Notify', source, "You're missing a lab!", 'error')
	end	
end)

RegisterServerEvent('ss-heroincar:finish')
AddEventHandler('ss-heroincar:finish', function(qualtiy)
	local _source = source
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	local rnd = math.random(-5, 5)
	xPlayer.Functions.AddItem('heroin', math.floor(qualtiy / 2) + rnd)	
end)

RegisterServerEvent('ss-heroincar:blow')
AddEventHandler('ss-heroincar:blow', function(posx, posy, posz)
	local _source = source
	local xPlayers = QBCore.Functions.GetPlayers()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	for i=1, #xPlayers, 1 do
		TriggerClientEvent('ss-heroincar:blowup', xPlayers[i],posx, posy, posz)
	end
	xPlayer.Functions.RemoveItem('methlab', 1)
end)

